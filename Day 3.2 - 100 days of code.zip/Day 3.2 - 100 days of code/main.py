"""
This program calculate body mass index ratio.
Based on the BMI value we will classify them.
"""

height = float(input("Enter the height: "))
weight = float(input("Enter the weight: "))

BMI = weight/(height * height)

if BMI < 18.0:
    print("Person is Under Weight")
elif BMI < 25:
    print("Person is Normal Weight")
elif BMI < 30:
    print("Person is Over Weight")
elif BMI < 35:
    print("Person is Obese")
else:
    print("Person is Clinically Obese")